If you press display button 2 for a long time,
you'll enter the on-the-go menu.

Use display button 1 to go up, button 2 to go down.
A long press of button 1 or button 2 will activate the current item.

The menu closes automatically after selecting an item.
